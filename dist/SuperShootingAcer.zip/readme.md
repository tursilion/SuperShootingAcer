19991208

Welcome to ** Super Shooting Acer **!!

A silly and short target diversion... surprisingly difficult and rather
fun to play... instructions are given on the title screen, but in short:

You will see a screen of 8 characters. Four are harmless, four are
dangerous. Study them. KNOW them. You will have to identify them
at a glance.

Five boxes will appear. Characters will scroll upwards inside the boxes
in random order. You *must* shoot the dangerous characters (they're
pointing guns at you) before they fully appear, or you will take a 'miss'.

You also *must* leave the harmless characters alone until they reach the
top and disappear on their own. If you shoot them, 'NO!' will flash, and
you will again take a 'miss'.

A 'miss' causes the character to flash with accompanying tone. The game
will then continue from where it left off. (Hint: store shots at bad
guys you have time to see :) )

If you get 3 misses, the game is over.

RUNNING THE GAME
----------------

You need a fairly quick machine and VGA to fully enjoy this game. Slower
machines will run it. 

If your machine is detected to be a little slow, 'Warning - Slow Machine'
will be displayed so your friends can see it's not JUST great skill
giving you those high scores :).

From a DOS prompt, simply enter 'SHOTACER'.

To quit at any time, press <esc>.

